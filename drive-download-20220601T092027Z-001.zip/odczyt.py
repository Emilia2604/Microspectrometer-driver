
import numpy as np

y2source=np.zeros((288))
y2offset=np.zeros((288))

def read_source():
    global y2source
    ylin=[]
    filepath='/home/pi/Desktop/spectrum/source.txt'
    f = open(filepath, "r")
    linie=f.readlines()
    for line in linie:
        ylin.append(line.replace('\n',''))
    for x in range(0,288):
        y2source[x]=float(ylin[x+1])
        
        
def read_offset():
    global y2offset
    ylin=[]
    filepath='/home/pi/Desktop/spectrum/offset.txt'
    f = open(filepath, "r")
    linie=f.readlines()
    for line in linie:
        ylin.append(line.replace('\n',''))
    for x in range(0,288):
        y2offset[x]=float(ylin[x+1])
        

